# 基本配置分为小程序端配置和halo端开启api的配置

  
- [普通小程序端配置](/conf/wcconf)
  
- [Halo后台配置](/conf/haloconf)
