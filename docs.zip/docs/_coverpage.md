# mini-blog-halo <small>1.5.5</small>

> 使用此小程序的前提是使用`已有开源halo博客`，`mini-blog-halo`的所有api均来源于halo开放的API。

!> 做一款最简洁的微信小程序博客

[GitHub](https://github.com/wangsrGit119/mini-blog-halo) 
[Get Started](/guide)






